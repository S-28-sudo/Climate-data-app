export interface ClimateData {
  Date: string;
  Country: string;
  Latitude: number;
  Longitude: number;
  Temperature: number;
  Humidity: number;
}

export interface FilterState {
  country: string | 'All';
  startDate: string;
  endDate: string;
  minTemp?: number;
  maxTemp?: number;
  minHumidity?: number;
  maxHumidity?: number;
}
