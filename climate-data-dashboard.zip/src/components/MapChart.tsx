import React, { useMemo } from 'react';
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  ZoomableGroup
} from 'react-simple-maps';
import { scaleLinear } from 'd3-scale';
import { ClimateData } from '../types';

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

interface MapChartProps {
  data: ClimateData[];
  setTooltipContent: (content: string) => void;
}

export const MapChart: React.FC<MapChartProps> = ({ data, setTooltipContent }) => {
  // Calculate average temperature per country for the given filtered data
  const aggregatedData = useMemo(() => {
    const map = new Map<string, { lat: number, lon: number, tempSum: number, count: number }>();
    data.forEach(d => {
      if (!map.has(d.Country)) {
        map.set(d.Country, { lat: d.Latitude, lon: d.Longitude, tempSum: 0, count: 0 });
      }
      const entry = map.get(d.Country)!;
      entry.tempSum += d.Temperature;
      entry.count += 1;
    });
    
    return Array.from(map.entries()).map(([country, stats]) => ({
      country,
      lat: stats.lat,
      lon: stats.lon,
      avgTemp: stats.tempSum / stats.count
    }));
  }, [data]);

  const colorScale = scaleLinear<string>()
    .domain([-10, 0, 15, 30, 40])
    .range(["#313695", "#74add1", "#ffffbf", "#f46d43", "#a50026"]);

  return (
    <div className="w-full h-[400px] bg-slate-950/50 rounded-2xl overflow-hidden relative border border-white/5 shadow-inner">
      <ComposableMap projectionConfig={{ scale: 140 }} width={800} height={400}>
        <ZoomableGroup center={[0, 20]} zoom={1}>
          <Geographies geography={geoUrl}>
            {({ geographies }) =>
              geographies.map((geo) => (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill="#1e293b"
                  stroke="#334155"
                  strokeWidth={0.5}
                  style={{
                    default: { outline: "none" },
                    hover: { outline: "none", fill: "#334155" },
                    pressed: { outline: "none" },
                  }}
                />
              ))
            }
          </Geographies>
          
          {aggregatedData.map(({ country, lat, lon, avgTemp }) => (
            <Marker 
              key={country} 
              coordinates={[lon, lat]}
              onMouseEnter={() => {
                setTooltipContent(`${country}: ${avgTemp.toFixed(1)}°C`);
              }}
              onMouseLeave={() => {
                setTooltipContent("");
              }}
            >
              <circle 
                r={8} 
                fill={colorScale(avgTemp)} 
                stroke="#0f172a" 
                strokeWidth={1}
                className="transition-all duration-300 hover:scale-150 hover:drop-shadow-[0_0_8px_rgba(255,255,255,0.6)] origin-center cursor-pointer"
                style={{ opacity: 0.8 }}
              />
            </Marker>
          ))}
        </ZoomableGroup>
      </ComposableMap>
      
      {/* Legend */}
      <div className="absolute bottom-4 right-4 bg-slate-900/80 backdrop-blur-md p-3 rounded-xl shadow-lg border border-white/10 text-xs">
        <div className="font-semibold mb-2 text-slate-300">Avg Temperature</div>
        <div className="flex items-center gap-1 h-3 w-32 rounded-full overflow-hidden">
          <div className="flex-1 h-full bg-[#313695]"></div>
          <div className="flex-1 h-full bg-[#74add1]"></div>
          <div className="flex-1 h-full bg-[#ffffbf]"></div>
          <div className="flex-1 h-full bg-[#f46d43]"></div>
          <div className="flex-1 h-full bg-[#a50026]"></div>
        </div>
        <div className="flex justify-between mt-1 text-slate-500">
          <span>-10°C</span>
          <span>40°C</span>
        </div>
      </div>
    </div>
  );
};
