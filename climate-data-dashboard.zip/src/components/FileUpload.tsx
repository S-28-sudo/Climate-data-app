import React, { useCallback } from 'react';
import Papa from 'papaparse';
import { UploadCloud, Database } from 'lucide-react';
import { ClimateData } from '../types';

interface FileUploadProps {
  onDataLoaded: (data: ClimateData[]) => void;
  onLoadDefault?: () => void;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onDataLoaded, onLoadDefault }) => {
  const handleFileUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: (results) => {
          onDataLoaded(results.data as ClimateData[]);
        },
        error: (error) => {
          console.error('Error parsing CSV:', error);
          alert('Failed to parse CSV file.');
        }
      });
    }
  }, [onDataLoaded]);

  return (
    <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-white/20 rounded-2xl bg-slate-900/40 backdrop-blur-xl hover:bg-slate-800/60 transition-colors relative h-full shadow-lg">
      <input
        type="file"
        accept=".csv"
        onChange={handleFileUpload}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
      />
      <UploadCloud className="w-12 h-12 text-slate-500 mb-4" />
      <p className="text-lg font-medium text-slate-300">Upload Climate Dataset (CSV)</p>
      
      {onLoadDefault && (
        <div className="mt-4 flex flex-col items-center z-20 relative">
          <p className="text-sm text-slate-500 mb-2">or</p>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onLoadDefault();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600/80 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium transition-colors shadow-md"
          >
            <Database className="w-4 h-4" />
            Load Sample Dataset
          </button>
        </div>
      )}
    </div>
  );
};
