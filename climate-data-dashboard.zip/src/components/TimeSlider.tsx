import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react';
import { format, parseISO } from 'date-fns';

interface TimeSliderProps {
  dates: string[];
  currentDate: string;
  setCurrentDate: (date: string) => void;
}

export const TimeSlider: React.FC<TimeSliderProps> = ({ dates, currentDate, setCurrentDate }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const currentIndex = dates.indexOf(currentDate);
  const maxIndex = dates.length - 1;

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        const idx = dates.indexOf(currentDate);
        if (idx >= maxIndex) {
          setIsPlaying(false);
        } else {
          setCurrentDate(dates[idx + 1]);
        }
      }, 150); // 150ms per step for smooth viewing
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, dates, maxIndex, setCurrentDate, currentDate]);

  const handlePlayPause = () => {
    if (currentIndex >= maxIndex && !isPlaying) {
      setCurrentDate(dates[0]);
    }
    setIsPlaying(!isPlaying);
  };

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newIndex = parseInt(e.target.value, 10);
    setCurrentDate(dates[newIndex]);
  };

  const handleStepBack = () => {
    if (currentIndex > 0) setCurrentDate(dates[currentIndex - 1]);
  };

  const handleStepForward = () => {
    if (currentIndex < maxIndex) setCurrentDate(dates[currentIndex + 1]);
  };

  if (dates.length === 0) return null;

  return (
    <div className="bg-slate-900/40 backdrop-blur-xl p-5 rounded-2xl shadow-lg border border-white/5 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-400">Time Animation</h3>
        <span className="text-indigo-400 font-bold bg-indigo-500/20 px-4 py-1.5 rounded-full text-sm border border-indigo-500/20">
          {currentDate ? format(parseISO(currentDate), 'MMMM yyyy') : ''}
        </span>
      </div>
      
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <button 
            onClick={handleStepBack}
            disabled={currentIndex <= 0}
            className="p-1.5 rounded-full text-slate-400 hover:bg-slate-800 disabled:opacity-50 transition-colors"
            title="Previous Step"
          >
            <SkipBack className="w-4 h-4" />
          </button>
          <button 
            onClick={handlePlayPause}
            className="p-2.5 rounded-full bg-indigo-600 text-white hover:bg-indigo-500 transition-all shadow-lg hover:shadow-indigo-500/25"
            title={isPlaying ? "Pause" : "Play"}
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
          </button>
          <button 
            onClick={handleStepForward}
            disabled={currentIndex >= maxIndex}
            className="p-1.5 rounded-full text-slate-400 hover:bg-slate-800 disabled:opacity-50 transition-colors"
            title="Next Step"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>
        
        <input 
          type="range" 
          min={0} 
          max={maxIndex} 
          value={currentIndex !== -1 ? currentIndex : 0} 
          onChange={handleSliderChange}
          className="flex-1 h-2 bg-slate-800/80 rounded-lg appearance-none cursor-pointer accent-indigo-500"
        />
      </div>
    </div>
  );
};
