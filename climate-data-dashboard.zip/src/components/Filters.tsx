import React from 'react';
import { FilterState } from '../types';
import { Download } from 'lucide-react';

interface FiltersProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  countries: string[];
  minDate: string;
  maxDate: string;
  onExport: () => void;
}

export const Filters: React.FC<FiltersProps> = ({ filters, setFilters, countries, minDate, maxDate, onExport }) => {
  return (
    <div className="flex flex-col gap-4 p-5 bg-slate-900/40 backdrop-blur-xl rounded-2xl shadow-lg border border-white/5">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <label className="block text-sm font-medium text-slate-400 mb-1">Country / Region</label>
          <select
            value={filters.country}
            onChange={(e) => setFilters(prev => ({ ...prev, country: e.target.value }))}
            className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border transition-colors"
          >
            <option value="All">Global (All Regions)</option>
            {countries.map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div className="flex-1">
          <label className="block text-sm font-medium text-slate-400 mb-1">Start Date</label>
          <input
            type="date"
            value={filters.startDate}
            min={minDate}
            max={filters.endDate || maxDate}
            onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
            className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border [color-scheme:dark] transition-colors"
          />
        </div>
        <div className="flex-1">
          <label className="block text-sm font-medium text-slate-400 mb-1">End Date</label>
          <input
            type="date"
            value={filters.endDate}
            min={filters.startDate || minDate}
            max={maxDate}
            onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
            className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border [color-scheme:dark] transition-colors"
          />
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="flex-1 flex gap-2">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-400 mb-1">Min Temp (°C)</label>
            <input
              type="number"
              value={filters.minTemp ?? ''}
              onChange={(e) => setFilters(prev => ({ ...prev, minTemp: e.target.value ? Number(e.target.value) : undefined }))}
              placeholder="Min"
              className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border transition-colors"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-400 mb-1">Max Temp (°C)</label>
            <input
              type="number"
              value={filters.maxTemp ?? ''}
              onChange={(e) => setFilters(prev => ({ ...prev, maxTemp: e.target.value ? Number(e.target.value) : undefined }))}
              placeholder="Max"
              className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border transition-colors"
            />
          </div>
        </div>
        
        <div className="flex-1 flex gap-2">
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-400 mb-1">Min Humidity (%)</label>
            <input
              type="number"
              value={filters.minHumidity ?? ''}
              onChange={(e) => setFilters(prev => ({ ...prev, minHumidity: e.target.value ? Number(e.target.value) : undefined }))}
              placeholder="Min"
              className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border transition-colors"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-slate-400 mb-1">Max Humidity (%)</label>
            <input
              type="number"
              value={filters.maxHumidity ?? ''}
              onChange={(e) => setFilters(prev => ({ ...prev, maxHumidity: e.target.value ? Number(e.target.value) : undefined }))}
              placeholder="Max"
              className="w-full rounded-xl bg-slate-950/80 border-white/10 text-slate-200 shadow-inner focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm p-2.5 border transition-colors"
            />
          </div>
        </div>

        <div className="w-full md:w-auto mt-4 md:mt-0">
          <button
            onClick={onExport}
            className="w-full md:w-auto flex items-center justify-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-lg shadow-indigo-500/20 transition-all font-medium"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        </div>
      </div>
    </div>
  );
};
