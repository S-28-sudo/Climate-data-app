import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';
import { GoogleGenAI, FunctionDeclaration, Type } from '@google/genai';

// Initialize the Gemini API client
const ai = new GoogleGenAI({ apiKey: (import.meta as any).env?.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '' });

interface ChatbotProps {
  onCountryChange?: (country: string) => void;
  countries?: string[];
}

export const Chatbot: React.FC<ChatbotProps> = ({ onCountryChange, countries = [] }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([
    { role: 'model', text: 'Hello! I am your Climate Dashboard Assistant. How can I help you explore the data today?' }
  ]);
  const [history, setHistory] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSend = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;
    
    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const changeCountryFunctionDeclaration: FunctionDeclaration = {
        name: "changeCountry",
        parameters: {
          type: Type.OBJECT,
          description: "Change the selected country/region in the dashboard.",
          properties: {
            country: {
              type: Type.STRING,
              description: `The name of the country or region to select. Available options: 'All', ${countries.slice(0, 100).map(c => `'${c}'`).join(', ')}...`,
            },
          },
          required: ["country"],
        },
      };

      const newHistory = [...history, { role: 'user', parts: [{ text: userMessage }] }];

      const systemInstruction = "You are a helpful assistant for a Global Climate Dashboard app. The app shows temperature and humidity trends from 2010 to 2023. It features a heatmap, a time-series chart, and an animated time slider. Answer the user's question concisely and helpfully. If the user asks to change the country or region, use the changeCountry tool.";

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: newHistory,
        config: {
          systemInstruction,
          tools: [{ functionDeclarations: [changeCountryFunctionDeclaration] }],
        },
      });
      
      const functionCalls = response.functionCalls;
      if (functionCalls && functionCalls.length > 0) {
        const call = functionCalls[0];
        if (call.name === 'changeCountry' && call.args && typeof call.args.country === 'string') {
          const newCountry = call.args.country;
          
          let matchedCountry = newCountry;
          if (newCountry !== 'All') {
            const exactMatch = countries.find(c => c.toLowerCase() === newCountry.toLowerCase());
            if (exactMatch) {
              matchedCountry = exactMatch;
            } else {
              const fuzzyMatch = countries.find(c => c.toLowerCase().includes(newCountry.toLowerCase()) || newCountry.toLowerCase().includes(c.toLowerCase()));
              if (fuzzyMatch) {
                matchedCountry = fuzzyMatch;
              }
            }
          }

          if (onCountryChange) {
            onCountryChange(matchedCountry);
            
            newHistory.push(response.candidates?.[0]?.content);
            newHistory.push({
              role: 'user',
              parts: [{
                functionResponse: {
                  name: 'changeCountry',
                  response: { success: true, country: matchedCountry }
                }
              }]
            });

            const finalResponse = await ai.models.generateContent({
              model: 'gemini-3-flash-preview',
              contents: newHistory,
              config: {
                systemInstruction,
                tools: [{ functionDeclarations: [changeCountryFunctionDeclaration] }],
              },
            });

            newHistory.push(finalResponse.candidates?.[0]?.content);
            setHistory(newHistory);
            setMessages(prev => [...prev, { role: 'model', text: finalResponse.text || `I have updated the dashboard to show data for ${matchedCountry}.` }]);
          }
        }
      } else {
        newHistory.push(response.candidates?.[0]?.content);
        setHistory(newHistory);
        setMessages(prev => [...prev, { role: 'model', text: response.text || 'Sorry, I could not generate a response.' }]);
      }
    } catch (error) {
      console.error('Chatbot error:', error);
      setMessages(prev => [...prev, { role: 'model', text: 'Sorry, I encountered an error. Please check your API key or try again later.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Chatbot Toggle Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 p-4 bg-indigo-600 text-white rounded-full shadow-lg hover:bg-indigo-500 transition-all z-50 ${isOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'}`}
      >
        <MessageSquare className="w-6 h-6" />
      </button>

      {/* Chatbot Window */}
      <div className={`fixed bottom-6 right-6 w-80 sm:w-96 bg-slate-900/80 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl flex flex-col overflow-hidden transition-all duration-300 z-50 origin-bottom-right ${isOpen ? 'scale-100 opacity-100' : 'scale-0 opacity-0 pointer-events-none'}`} style={{ height: '500px', maxHeight: '80vh' }}>
        {/* Header */}
        <div className="bg-slate-800/50 p-4 flex items-center justify-between border-b border-white/5">
          <div className="flex items-center gap-2">
            <Bot className="w-5 h-5 text-indigo-400" />
            <h3 className="font-semibold text-white">Dashboard Assistant</h3>
          </div>
          <button onClick={() => setIsOpen(false)} className="text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.role === 'user' ? 'bg-indigo-600' : 'bg-slate-800 border border-white/5'}`}>
                {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-indigo-400" />}
              </div>
              <div className={`px-4 py-2 rounded-2xl max-w-[85%] text-sm ${msg.role === 'user' ? 'bg-indigo-600 text-white rounded-tr-none shadow-md' : 'bg-slate-800/80 backdrop-blur-sm text-slate-200 border border-white/5 rounded-tl-none shadow-md'}`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3 flex-row">
              <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/5 flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="px-4 py-3 rounded-2xl bg-slate-800/80 backdrop-blur-sm border border-white/5 rounded-tl-none flex items-center gap-1 shadow-md">
                <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-3 border-t border-white/5 bg-slate-800/50">
          <form onSubmit={handleSend} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question..."
              className="flex-1 bg-slate-950/50 border border-white/10 rounded-full px-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 shadow-inner"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="p-2 bg-indigo-600 text-white rounded-full hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </>
  );
};
