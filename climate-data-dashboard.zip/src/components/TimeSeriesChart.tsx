import React, { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
  ReferenceLine
} from 'recharts';
import { format, parseISO } from 'date-fns';
import { ClimateData } from '../types';

interface TimeSeriesChartProps {
  data: ClimateData[];
  selectedCountry: string;
  currentDate?: string;
}

export const TimeSeriesChart: React.FC<TimeSeriesChartProps> = ({ data, selectedCountry, currentDate }) => {
  const baseChartData = useMemo(() => {
    if (selectedCountry === 'All') {
      // Aggregate global average per date
      const map = new Map<string, { tempSum: number, count: number, humiditySum: number }>();
      data.forEach(d => {
        if (!map.has(d.Date)) {
          map.set(d.Date, { tempSum: 0, count: 0, humiditySum: 0 });
        }
        const entry = map.get(d.Date)!;
        entry.tempSum += d.Temperature;
        entry.humiditySum += (d.Humidity || 0);
        entry.count += 1;
      });
      
      return Array.from(map.entries()).map(([date, stats]) => ({
        date,
        temperature: stats.tempSum / stats.count,
        humidity: stats.humiditySum / stats.count,
        formattedDate: format(parseISO(date), 'MMM yyyy')
      })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    } else {
      // Filter for specific country
      return data
        .filter(d => d.Country === selectedCountry)
        .map(d => ({
          date: d.Date,
          temperature: d.Temperature,
          humidity: d.Humidity || 0,
          formattedDate: format(parseISO(d.Date), 'MMM yyyy')
        }))
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }
  }, [data, selectedCountry]);

  if (baseChartData.length === 0) {
    return <div className="h-[400px] flex items-center justify-center text-slate-500">No data available for the selected filters.</div>;
  }

  return (
    <div className="w-full h-[400px] bg-slate-950/50 p-5 rounded-2xl border border-white/5 shadow-inner">
      <h3 className="text-lg font-semibold text-slate-200 mb-4">
        {selectedCountry === 'All' ? 'Global Average Temperature & Humidity Trends' : `${selectedCountry} Temperature & Humidity Trends`}
      </h3>
      <ResponsiveContainer width="100%" height="90%">
        <AreaChart data={baseChartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
            </linearGradient>
            <linearGradient id="colorHumidity" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#0ea5e9" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff10" />
          <XAxis 
            dataKey="formattedDate" 
            tick={{ fill: '#94a3b8', fontSize: 12 }}
            tickMargin={10}
            minTickGap={30}
          />
          <YAxis 
            yAxisId="left"
            tick={{ fill: '#94a3b8', fontSize: 12 }}
            tickFormatter={(value) => `${value}°C`}
            domain={['auto', 'auto']}
          />
          <YAxis 
            yAxisId="right" 
            orientation="right"
            tick={{ fill: '#94a3b8', fontSize: 12 }}
            tickFormatter={(value) => `${value}%`}
            domain={[0, 100]}
          />
          <Tooltip 
            contentStyle={{ borderRadius: '8px', border: '1px solid #334155', backgroundColor: '#1e293b', color: '#f8fafc', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
            labelStyle={{ fontWeight: 'bold', color: '#f8fafc' }}
          />
          <Legend verticalAlign="top" height={36} wrapperStyle={{ color: '#cbd5e1' }}/>
          {currentDate && baseChartData.some(d => d.date === currentDate) && (
            <ReferenceLine 
              x={format(parseISO(currentDate), 'MMM yyyy')} 
              stroke="#818cf8" 
              strokeDasharray="3 3"
              strokeWidth={2}
            />
          )}
          <Area 
            yAxisId="left"
            type="monotone" 
            dataKey="temperature" 
            name="Temperature (°C)"
            stroke="#f43f5e" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorTemp)" 
          />
          <Area 
            yAxisId="right"
            type="monotone" 
            dataKey="humidity" 
            name="Humidity (%)"
            stroke="#0ea5e9" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorHumidity)" 
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
